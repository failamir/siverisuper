<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }

    public function index()
    {
        $this->form_validation->set_rules('user_id', 'User id', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');

        if ($this->form_validation->run() == false) {
            $this->load->view('auth/login_2');
        } else {
            $this->_login();
        }
    }

    private function _login()
    {
        $user_id = $this->input->post('user_id');
        $password = $this->input->post('password');

        $user = $this->db->get_where('user', ['id' => $user_id])->row_array();

        if ($user) {
            if ($password == $user['password']) {
                $data = [
                    'id' => $user['id'],
                    'name' => $user['name']
                ];
                $this->session->set_userdata($data);
                if ($user['user_role'] == 1) {
                    redirect('Verivikator');
                } elseif ($user['user_role'] == 2) {
                    redirect('Opd');
                } elseif ($user['user_role'] == 3) {
                    redirect('Admin');
                }
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Password Salah</div>');
                redirect('Auth');
            }
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">User ID Salah</div>');
            redirect('Auth');
        }
    }

    public function logout()
    {
        $this->session->unset_userdata('id');
        $this->session->unset_userdata('name');
        $this->session->unset_userdata('spm');
        redirect('Auth');
    }
}
