<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Verifikator_2 extends CI_Controller
{
    public function index()
    {
        $data['title'] = 'Verifikator';
        $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();

        $data['document'] = $this->db->get_where('document', ['status' => 3])->result_array();

        $this->load->view('verifikator_2/index', $data);
    }

    public function button()
    {
        $spm = $this->input->post('spm');
        $status = $this->input->post('status');
        $window = $this->input->post('window');

        $this->db->where('spm', $spm);
        $this->db->update('document', $status);

        if ($window == '1') {
            redirect('verifikator');
        } elseif ($window == '2') {
            $this->_lolos($status);
        } elseif ($window == '3') {
            $this->_revisi($status);
        }
    }

    private function catatan()
    {
        $spm = $this->input->post('spm');
        $catatan = $this->input->post('catatan');
        $this->form_validation->set_rules('catatan', 'Catatan', 'required');

        if ($this->form_validation->run() == false) {
            $data['title'] = 'Verivicator';
            $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();
            $data['spm'] = $spm;
            $this->load->view('verivikator/catatan', $data);
        } else {


            $upload_image = $_FILES['image']['name'];

            if ($upload_image) {
                $config['upload_path']          = './assets/img/comments/';
                $config['allowed_types']        = 'gif|jpg|png|jpeg';
                $config['max_size']             = 1024;

                $this->load->library('upload', $config);

                $this->upload->do_upload('image');

                $image_name = $this->upload->data('file_name');
            } else {
                $image_name = 'default.png';
            }

            $data = [
                'spm' => $spm,
                'catatan' => $catatan,
                'image' => $image_name
            ];
            $this->db->insert('comments', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Komentar berhasil ditambahkan</div>');
            $data['title'] = 'Verivicator';
            $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();
            $data['spm'] = $spm;
            $this->load->view('verifikator_2/catatan', $data);
        }
    }

    private function _lolos($status)
    {
        $data['title'] = 'Verifikator';
        $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();

        $data[document] = $this->db->get_where('document', ['status' => $status])->result_array();

        $this->load->view('verifikator_2/lolos.php', $data);
    }

    private function _revisi($status)
    {
        $data['title'] = 'Verifikator';
        $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();

        $data[document] = $this->db->get_where('document', ['status' => $status])->result_array();

        $this->load->view('verifikator_2/lolos.php');
    }
}
