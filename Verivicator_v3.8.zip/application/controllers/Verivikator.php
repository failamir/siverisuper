<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Verivikator extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = 'Verivicator';
        $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();
        $this->db->where('status', '0');
        $this->db->or_where('status', '1');
        $data['document'] = $this->db->get('document')->result_array();

        $data['pengguna'] = $this->db->get('user')->result_array();

        $this->load->view('verivikator/index', $data);
    }

    public function button()
    {
        $window = $this->input->post('window');
        $spm = $this->input->post('spm');
        $status = $this->input->post('status');
        $penerima = $this->input->post('penerima');

        if ($status == 0 && $window == 1) {
            $data = [
                'penerima_berkas' => 0,
                'status' => $status
            ];
        } elseif ($status == 1 && $window == 1) {
            $data = [
                'penerima_berkas' => $penerima,
                'status' => $status
            ];
        } elseif ($status == 2 && $window == 1) {
            $condition = $this->db->get_where('document', ['spm' => $spm])->row_array();
            if ($condition['penerima_berkas'] == 0) {
                $data = [
                    'verivikator' => $this->session->userdata('id'),
                    'status' => $status,
                    'penerima_berkas' => $penerima
                ];
            } else {
                $data = [
                    'verivikator' => $this->session->userdata('id'),
                    'status' => $status
                ];
            }
        } elseif ($status == 1 && $window == 2) {
            $data = [
                'verivikator' => 0,
                'status' => $status
            ];
        } else {
            $data = [
                'status' => $status
            ];
        }

        $this->db->where('spm', $spm);
        $this->db->update('document', $data);
        if ($window == '1') {
            redirect('verivikator');
        } elseif ($window == '2') {
            redirect('verivikator/tugas');
        } elseif ($window == '3') {
            redirect('verivikator/lolos');
        } elseif ($window == '4') {
            redirect('verivikator/revisi');
        } else {
            $data['title'] = 'Verivicator';
            $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();
            $data['spm'] = $spm;
            $this->load->view('verivikator/catatan', $data);
        }
    }

    public function catatan()
    {
        $spm = $this->input->post('spm');
        $catatan = $this->input->post('catatan');
        $status = $this->input->post('status');
        $this->form_validation->set_rules('catatan', 'Catatan', 'required');


        if ($this->form_validation->run() == false) {
            $data['title'] = 'Verivicator';
            $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();
            $data['spm'] = $spm;
            $this->load->view('verivikator/catatan', $data);
        } else {


            $upload_image = $_FILES['image']['name'];

            if ($upload_image) {
                $config['upload_path']          = './assets/img/comments/';
                $config['allowed_types']        = 'gif|jpg|png|jpeg';
                $config['max_size']             = 1024;

                $this->load->library('upload', $config);

                $this->upload->do_upload('image');

                $image_name = $this->upload->data('file_name');
            } else {
                $image_name = 'default.png';
            }

            $data = [
                'spm' => $spm,
                'catatan' => $catatan,
                'image' => $image_name,
                'status' => $status
            ];
            $this->db->insert('comments', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Catatan berhasil ditambahkan</div>');
            $data['title'] = 'Verivicator';
            $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();
            $data['spm'] = $spm;
            $this->load->view('verivikator/catatan', $data);
        }
    }

    public function tugas()
    {
        $data['title'] = 'Verivicator';
        $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();
        $condition = [
            'status' => '2',
            'verivikator' => $this->session->userdata('id')
        ];
        $data['document'] = $this->db->get_where('document', $condition)->result_array();

        $data['pengguna'] = $this->db->get('user')->result_array();

        $this->load->view('verivikator/tugas', $data);
    }

    public function lolos()
    {
        $data['title'] = 'Verivicator';
        $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();
        $condition = [
            'status' => '3',
            'verivikator' => $this->session->userdata('id')
        ];
        $data['document'] = $this->db->get_where('document', $condition)->result_array();

        $data['pengguna'] = $this->db->get('user')->result_array();

        $this->load->view('verivikator/lolos', $data);
    }

    public function revisi()
    {
        $data['title'] = 'Verivicator';
        $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();
        $condition = [
            'status' => '4',
            'verivikator' => $this->session->userdata('id')
        ];
        $data['document'] = $this->db->get_where('document', $condition)->result_array();

        $data['pengguna'] = $this->db->get('user')->result_array();

        $this->load->view('verivikator/revisi', $data);
    }

    public function about($document)
    {
        if ($document == 0) {
            $spm = $this->input->post('spm');
            $status = $this->input->post('status');
            $opd = $this->input->post('opd');
            $nominal = $this->input->post('nominal');
            $kegiatan = $this->input->post('kegiatan');
            $penerima = $this->input->post('penerima');
            $verivikator = $this->input->post('verivikator');
        } else {
            $spm = $document['spm'];
            $status = $document['status'];
            $opd = $document['opd'];
            $nominal = $document['nominal'];
            $kegiatan = $document['kegiatan'];
            $penerima = $document['penerima_berkas'];
            $verivikator = $document['verivikator'];
        }

        if ($status == 0) {
            $status = 'Berkas belum masuk';
        } elseif ($status == 1) {
            $status = 'Berkas sudah masuk';
        } elseif ($status == 2) {
            $status = 'Sedang dalam proses verifikasi';
        } elseif ($status == 3) {
            $status = 'Lolos';
        } else {
            $status = 'Revisi';
        }

        $data['title'] = 'OPD';
        $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();
        $opd = $this->__getUser($opd);
        $penerima = $this->__getUser($penerima);
        $verivikator = $this->__getUser($verivikator);
        $data['document'] = [
            'spm' => $spm,
            'opd' => $opd,
            'status' => $status,
            'nominal' => $nominal,
            'kegiatan' => $kegiatan,
            'penerima_berkas' => $penerima,
            'verivikator' => $verivikator
        ];
        $data['comment'] = $this->db->get_where('comments', ['spm' => $spm])->result_array();

        $this->load->view('verivikator/about', $data);
    }

    public function hapus()
    {
        $id = $this->input->post('id');
        $spm = $this->input->post('spm');

        $this->db->where('id', $id);
        $this->db->delete('comments');

        $verivikator = $this->db->get_where('document', ['spm' => $spm])->row_array();

        $this->about($verivikator);
    }

    private function __getUser($user)
    {
        $nama = $this->db->get_where('user', ['id' => $user])->row_array();

        return $nama['name'];
    }

    public function invoice()
    {
        $this->load->view('verivikator/invoice');
    }
}
