<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Opd extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = 'OPD';
        $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();
        $data['document'] = $this->db->get_where('document', ['opd' => $this->session->userdata('id')])->result_array();
        $this->load->view('opd/index', $data);
    }

    public function upload()
    {
        $this->form_validation->set_rules('spm', 'SPM', 'required|trim|is_unique[document.spm]');
        $this->form_validation->set_rules('kegiatan', 'Kegiatan', 'required|trim');
        $this->form_validation->set_rules('nominal', 'Nominal', 'required|trim');

        if ($this->form_validation->run() == false) {
            $data['title'] = 'OPD';
            $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();
            $this->load->view('opd/upload', $data);
        } else {
            $data = [
                'spm' => $this->input->post('spm'),
                'opd' => $this->session->userdata('id'),
                'kegiatan' => $this->input->post('kegiatan'),
                'nominal' => $this->input->post('nominal'),
                'verivikator' => '0',
                'penerima_berkas' => '0',
                'status' => 0
            ];

            $this->db->insert('document', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">SPM berhasil di upload</div>');
            redirect('opd/upload');
        }
    }

    public function about($document)
    {
        if ($document == 0) {
            $spm = $this->input->post('spm');
            $status = $this->input->post('status');
            $verivikator = $this->input->post('verivikator');
            $opd = $this->input->post('opd');
            $nominal = $this->input->post('nominal');
            $kegiatan = $this->input->post('kegiatan');
            $penerima = $this->input->post('penerima');
        } else {
            $spm = $document['opd']['spm'];
            $status = $document['opd']['status'];
            $verivikator = $document['opd']['verivikator'];
            $opd = $document['opd']['opd'];
            $nominal = $document['opd']['nominal'];
            $kegiatan = $document['opd']['kegiatan'];
            $penerima = $document['opd']['penerima_berkas'];
        }



        if ($status == 0) {
            $status = 'Berkas belum masuk';
        } elseif ($status == 1) {
            $status = 'Berkas sudah masuk';
        } elseif ($status == 2) {
            $status = 'Sedang di ferivkasi oleh ferivikator';
        } elseif ($status == 3) {
            $status = 'Lolos';
        } else {
            $status = 'Revisi';
        }

        $data['title'] = 'OPD';
        $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();
        $verivikator = $this->__getUser($verivikator);
        $penerima = $this->__getUser($penerima);
        $data['document'] = [
            'spm' => $spm,
            'opd' => $opd,
            'verivikator' => $verivikator,
            'status' => $status,
            'nominal' => $nominal,
            'kegiatan' => $kegiatan,
            'penerima_berkas' => $penerima
        ];
        $data['comment'] = $this->db->get_where('comments', ['spm' => $spm])->result_array();

        $this->load->view('opd/about', $data);
    }

    private function __getUser($user)
    {
        $nama = $this->db->get_where('user', ['id' => $user])->row_array();

        return $nama['name'];
    }

    public function hapus()
    {
        $this->db->where('spm', $this->input->post('spm'));
        $this->db->delete('document');

        $this->index();
    }

    public function update()
    {
        $id = $this->input->post('id');
        $spm = $this->input->post('spm');
        $status = $this->input->post('status');

        $condition = [
            'id' => $id,
            'spm' => $spm
        ];

        $update = [
            'status' => $status
        ];

        $this->db->where($condition);
        $this->db->update('comments', $update);

        $data['opd'] = $this->db->get_where('document', ['spm' => $spm])->row_array();

        $this->about($data);
    }
}
