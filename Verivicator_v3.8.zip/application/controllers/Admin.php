<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = 'Admin';
        $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();

        $data['lolos'] = $this->_getJumlah(3);
        $data['spm'] = $this->_getJumlah(null);
        $data['proses'] = $this->_getJumlah(2);
        $data['revisi'] = $this->_getJumlah(4);

        $data['verivikator'] = $this->db->get_where('user', ['user_role' => 1])->result_array();
        $data['opd'] = $this->db->get_where('user', ['user_role' => 2])->result_array();

        $i = 0;

        foreach ($data['verivikator'] as $value) {
            $condition = $value['id'];
            $data['verivikator'][$i]['spm'] = $this->_getJumlah($condition);
            $i++;
        }

        $i = 0;

        foreach ($data['opd'] as $value) {
            $condition = $value['id'];
            $data['opd'][$i]['spm'] = $this->_getJumlah($condition);
            $i++;
        }

        $this->load->view('admin/index', $data);
    }

    public function user($user_role)
    {
        $data['title'] = 'Admin';
        $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();

        if ($user_role == 1) {
            $data['verivikator'] = $this->db->get_where('user', ['user_role' => $user_role])->result_array();
            $this->load->view('admin/verivikator', $data);
        } elseif ($user_role == 2) {
            $data['opd'] = $this->db->get_where('user', ['user_role' => $user_role])->result_array();
            $this->load->view('admin/opd', $data);
        } else {
            $data['admin'] = $this->db->get_where('user', ['user_role' => $user_role])->result_array();
            $this->load->view('admin/admin', $data);
        }
    }

    public function document()
    {
        $data['title'] = 'Admin';
        $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();

        $data['spm'] = $this->db->get('document')->result_array();

        $data['pengguna'] = $this->db->get('user')->result_array();

        $data['status'] = $this->db->get('status')->result_array();

        $this->load->view('admin/spm', $data);
    }

    public function hapus()
    {


        $window = $this->input->post('window');

        if ($window == 1) {

            $this->db->where('id', $this->input->post('id'));
            $this->db->delete('user');

            $this->user(1);
        } elseif ($window == 2) {


            $this->db->where('id', $this->input->post('id'));
            $this->db->delete('user');

            $this->user(2);
        } elseif ($window == 3) {

            $this->db->where('spm', $this->input->post('id'));
            $this->db->delete('document');

            $this->document();
        } else {
            $this->db->where('id', $this->input->post('id'));
            $this->db->delete('user');

            $this->user(3);
        }
    }

    public function registrasi()
    {
        $id = $this->input->post('id');
        $id_awal = $this->input->post('id_awal');
        $name = $this->input->post('name');
        $password = $this->input->post('password');
        $user_role = $this->input->post('user_role');
        $window = $this->input->post('window');

        if ($id == $id_awal) {
            $this->form_validation->set_rules('id', 'ID', 'required');
            $this->form_validation->set_rules('name', 'Nama', 'trim|required');
            $this->form_validation->set_rules('password', 'Password', 'required');
        } else {
            $this->form_validation->set_rules('id', 'ID', 'is_unique[user.id]|required');
            $this->form_validation->set_rules('name', 'Nama', 'trim|required');
            $this->form_validation->set_rules('password', 'Password', 'required');
        }

        if ($this->form_validation->run() == false) {
            if ($window == 5 || $window == 6 || $window == 7) {
                $data['title'] = 'Admin';
                $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();

                $id = $id_awal;

                $data['edit'] = $this->db->get_where('user', ['id' => $id])->row_array();

                $this->load->view('admin/ubah', $data);
            } else {
                $data['title'] = 'Admin';
                $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();

                $this->load->view('admin/registrasi', $data);
            }
        } else {



            $upload_image = $_FILES['image']['name'];

            if ($upload_image) {
                $config['upload_path']          = './assets/img/profile/';
                $config['allowed_types']        = 'gif|jpg|png|jpeg';
                $config['max_size']             = 1024;

                $this->load->library('upload', $config);

                $this->upload->do_upload('image');

                $image_name = $this->upload->data('file_name');
            } else {
                $image_name = 'default.png';
            }

            $data = [
                'id' => $id,
                'name' => $name,
                'image' => $image_name,
                'password' => $password,
                'user_role' => $user_role

            ];
            if ($window == 5 || $window == 6 || $window == 7) {
                $this->db->where('id', $id_awal);
                $this->db->update('user', $data);

                $this->user($user_role);
            } else {
                $this->db->insert('user', $data);
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">User Berhasil Ditambahkan</div>');
                $data['title'] = 'admin';
                $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();

                $this->load->view('admin/registrasi', $data);
            }
        }
    }

    public function ubah()
    {
        $data['title'] = 'Admin';
        $data['user'] = $this->db->get_where('user', ['id' => $this->session->userdata('id')])->row_array();

        $id = $this->input->post('id');
        $window = $this->input->post('window');

        $data['edit'] = $this->db->get_where('user', ['id' => $id])->row_array();

        $this->load->view('admin/ubah', $data);
    }

    private function _getJumlah($status)
    {
        if ($status) {
            $this->db->where('status', $status);
            $this->db->or_where('verivikator', $status);
            $this->db->or_where('opd', $status);
            $this->db->from('document');
            $spm = $this->db->count_all_results();
        } else {
            $spm = $this->db->count_all_results('document');
        }

        return $spm;
    }
}
