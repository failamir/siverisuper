<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Custom fonts for this template-->
    <link href="<?= base_url('assets/'); ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?= base_url('assets/'); ?>css/sb-admin-2.min.css" rel="stylesheet">

    <title>Hello, world!</title>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4"></div>
            <div class="col-md-8 text-center">
                <div class="row">
                    <div class="col-md-12">
                        <h3>PEMERINTAH PROVINSI JAWA TENGAH</h3>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <h2>BADAN PENGERLOLA KEUANGAN DAN</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <h2>ASET DAERAH</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <p>Jalam Taman Mentri Supeno Nomor 2 Semarang Kode Pos 50243 Telpon 024-8311174</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <p>Faksimile 024-8311172 Laman http://bpkad.jatengprov.go.id</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <p>Surat Elektronik bppkad@jatengprov.go.id</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h3>TANDA TERIMA BREKAS PENCAIRAN BANTUAN</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <p>No. Regsiter :</p>
            </div>
        </div>
    </div>


    <!-- Optional JavaScript -->
    <!-- Bootstrap core JavaScript-->
    <script src="<?= base_url('assets/'); ?>vendor/jquery/jquery.min.js"></script>
    <script src="<?= base_url('assets/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?= base_url('assets/'); ?>vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?= base_url('assets/'); ?>js/sb-admin-2.min.js"></script>
</body>

</html>